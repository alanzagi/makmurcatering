
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script>

<script src="//unpkg.com/alpinejs" defer></script>
<?php /**PATH C:\laragon\www\makmurcatering\resources\views/components/end-body.blade.php ENDPATH**/ ?>