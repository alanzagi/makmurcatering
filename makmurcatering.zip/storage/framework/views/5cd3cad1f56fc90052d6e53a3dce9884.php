
<header class="bg-slate-600 text-center pb-[4.5em] md:pb-[4.75em]">
</header>

<?php /**PATH C:\laragon\www\makmurcatering\resources\views/components/header.blade.php ENDPATH**/ ?>