<div class="relative font-poppins">
    <button onclick="window.open('https://wa.me/6281521550913', '_blank')"
        class="z-20 text-white flex flex-col shrink-0 grow-0 justify-around 
                    fixed bottom-0 right-5 rounded-lg
                    mr-1 mb-5 lg:mr-5 lg:mb-5 xl:mr-10 xl:mb-10">
        <div class="p-3 rounded-full flex items-center gap-x-2 bg-[#25D366]">
            <p class="text-md capitalize">Chat Whatsapp</p>
            <img src="<?php echo e(asset('images/whatsapp.png')); ?>" alt="WhatsApp" class="w-6 h-6 rounded-full">
        </div>
    </button>
</div>
<?php /**PATH C:\laragon\www\makmurcatering\resources\views/components/whatsapp.blade.php ENDPATH**/ ?>