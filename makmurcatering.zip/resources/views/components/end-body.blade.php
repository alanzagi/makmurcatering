{{-- Internal Javascript --}}
<script src="{{ asset('js/script.js') }}"></script>
{{-- Flowbite Javascript --}}
<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script>
{{-- Alpine Js --}}
<script src="//unpkg.com/alpinejs" defer></script>
