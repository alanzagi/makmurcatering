{{-- Start header sebagai background navbar --}}
<header class="bg-slate-600 text-center pb-[4.5em] md:pb-[4.75em]">
</header>
{{-- Start header sebagai background navbar --}}
